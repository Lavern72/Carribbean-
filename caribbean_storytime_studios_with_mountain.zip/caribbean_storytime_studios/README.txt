CARIBBEAN STORYTIME STUDIOS — CINEMATIC HTML5 WEBSITE

Pages:
- index.html
- about.html
- projects.html
- healing-roots.html
- contact.html

Before publishing:
1. Replace the placeholder telephone number in contact.html.
2. Create a free Formspree form and replace REPLACE-WITH-YOUR-FORM-ID.
3. Confirm your email and domain name.
4. Replace any temporary project images when final production stills are available.

To preview: open index.html in a browser.
To publish: upload the entire folder to Netlify, Hostinger, SiteGround, or another web host.
