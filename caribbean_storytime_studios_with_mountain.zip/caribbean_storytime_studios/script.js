const button=document.querySelector('.menu-toggle');const menu=document.querySelector('.menu');if(button&&menu){button.addEventListener('click',()=>{menu.classList.toggle('open');button.setAttribute('aria-expanded',menu.classList.contains('open'));});menu.querySelectorAll('a').forEach(link=>link.addEventListener('click',()=>{menu.classList.remove('open');button.setAttribute('aria-expanded','false');}));}
document.querySelectorAll('[data-year]').forEach(el=>el.textContent=new Date().getFullYear());

// Cinematic scroll-reveal
if('IntersectionObserver' in window){
  const revealTargets=document.querySelectorAll('.section-title, .lead, .card, .feature, .project-feature, .value, .quote, .contact-item, .partner-box, form');
  revealTargets.forEach(el=>el.classList.add('reveal'));
  const observer=new IntersectionObserver((entries)=>{
    entries.forEach(entry=>{
      if(entry.isIntersecting){
        entry.target.classList.add('in-view');
        observer.unobserve(entry.target);
      }
    });
  },{threshold:0.15,rootMargin:'0px 0px -40px 0px'});
  revealTargets.forEach(el=>observer.observe(el));
}
